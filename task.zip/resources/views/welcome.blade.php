@extends('layout')
@section('title' ,'Home')
@section('content')
<div class="container mt-5">
     <h1 class=" text-center ms-auto me-auto">"Welcome to the Home Page. This page will only appear when the user is logged in."</h1>
</div>


@endsection