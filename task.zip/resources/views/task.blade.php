@extends('layout')
@section('title' ,'Task')
@section('content')
<div class="container mt-5">
     <h1 class=" text-center ms-auto me-auto">Log In Registration Task Done!!</h1>
</div>


@endsection