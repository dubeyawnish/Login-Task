
<?php $__env->startSection('title' ,'Task'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
     <h1 class=" text-center ms-auto me-auto">Log In Registration Task Done!!</h1>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\PHP Project\Assignment1\task\resources\views/task.blade.php ENDPATH**/ ?>