<?php $__env->startSection('title' ,'Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
     <h1 class=" text-center ms-auto me-auto">"Welcome to the Home Page. This page will only appear when the user is logged in."</h1>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\PHP Project\Assignment1\task\resources\views/welcome.blade.php ENDPATH**/ ?>